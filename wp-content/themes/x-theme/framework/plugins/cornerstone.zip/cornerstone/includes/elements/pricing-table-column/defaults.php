<?php

/**
 * Element Defaults: Pricing Table Column
 */

return array(
	'id'           => '',
	'class'        => '',
	'style'        => '',
	'title'        => '',
	'content'      => '',
	'featured'     => false,
	'featured_sub' => '',
	'currency'     => '$',
	'price'        => '29',
	'interval'     => 'Per Month'
);