<?php

/**
 * Element Defaults: Text
 */

return array(
	'id'         => '',
	'class'      => '',
	'style'      => '',
	'text_align' => '',
	'content'    => '',
);