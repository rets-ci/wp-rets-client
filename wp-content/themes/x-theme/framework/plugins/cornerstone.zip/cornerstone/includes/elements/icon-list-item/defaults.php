<?php

/**
 * Element Defaults: Icon List Item
 */

return array(
	'id'           => '',
	'class'        => '',
	'style'        => '',
	'title'        => '',
	'type'         => '',
	'icon_color'   => '',
	'link_enabled' => false,
	'link_url'     => '#',
	'link_title'   => '',
	'link_new_tab' => false
);