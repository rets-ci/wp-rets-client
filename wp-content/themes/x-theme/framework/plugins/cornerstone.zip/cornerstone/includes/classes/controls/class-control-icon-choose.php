<?php
class Cornerstone_Control_Icon_Choose extends Cornerstone_Control {

	protected $default_options = array(
		'expandable'  => true,
	);

	protected $default_value = 'star';

}