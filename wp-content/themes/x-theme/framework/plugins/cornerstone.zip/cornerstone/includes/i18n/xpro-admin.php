<?php

/**
 * Localize strings for javascript
 */

return array(
	'edit-with-cornerstone'      => __( 'Edit with Pro', 'cornerstone' ),
	'cornerstone-tab'            => __( 'Pro', 'cornerstone' ),
	'default-title'              => __( 'Content Draft', 'cornerstone')
);
